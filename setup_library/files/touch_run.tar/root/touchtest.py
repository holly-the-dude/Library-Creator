#!/usr/bin/python3
import evdev
from evdev import InputDevice, categorize, ecodes

# Replace with your touchscreen device path (this is an example, find the correct one using 'ls /dev/input')
device_path = '/dev/input/event0'

# Create an InputDevice instance
device = InputDevice(device_path)

print("Touchscreen device found: ", device.name)
print("Listening for touch events...")

try:
    for event in device.read_loop():
        # Only consider events for the touchscreen
        if event.type == ecodes.EV_ABS:
            if event.code == ecodes.ABS_X:
                print(f"X Position: {event.value}")
            elif event.code == ecodes.ABS_Y:
                print(f"Y Position: {event.value}")
        elif event.type == ecodes.EV_KEY and event.code == ecodes.BTN_TOUCH:
            if event.value == 1:
                print("Touch event detected")
            elif event.value == 0:
                print("Touch event released")

except KeyboardInterrupt:
    print("\nExiting touch event listener.")

