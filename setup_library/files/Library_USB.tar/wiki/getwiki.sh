    echo -e "${YELLOW}"
    echo "╔══════════════════════════════════════════════════╗"
    echo "║  Getting base wiki for blank usb                 ║"
    echo "║  This only works if you have the ethernet        ║"
    echo "║  plugged in if you dont then dont worry you can  ║"
    echo "║  add a zim file manually later                   ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo -e "${NC}"

if wget --quiet --spider --timeout=10 --tries=1 https://dumps.wikimedia.org/; then
    wget https://dumps.wikimedia.org/kiwix/zim/wikipedia/wikipedia_en_100_2026-08.zim
else
    echo "Cannot reach the download server. Check your internet connection."
    echo "Skipping the wiki download; you can add a ZIM file manually later."
fi

