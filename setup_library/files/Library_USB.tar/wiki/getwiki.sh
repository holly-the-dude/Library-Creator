    echo -e "${YELLOW}"
    echo "╔══════════════════════════════════════════════════╗"
    echo "║  Getting base wiki for blank usb                 ║"
    echo "║  This only works if you have the ethernet        ║"
    echo "║  plugged in if you dont then dont worry you can  ║"
    echo "║  add a zim file manually later                   ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo -e "${NC}"

wget https://dumps.wikimedia.org/kiwix/zim/wikipedia/wikipedia_en_100_2026-08.zim


