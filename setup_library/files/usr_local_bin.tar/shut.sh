#!/bin/bash
nohup /usr/local/bin/library_shutdown.py &
